Steps to run Geth:

1. Extract the Geth folder to desktop
2. Run "1_Genesis.bat" file which will execute the rpcapi and initialize the "genesis.json" file
3. Run "2_runGeth.bat" file which will run the Geth.exe in order for us to use the Geth Console
4. Run "3_runGethAttach.bat" file which will run the Geth Console in order for us to use commands from the rpcapi


* Run "clearchain.bat" file which will remove the Data folder from Geth folder and the Ethereum folder from AppData folder
* Optional ~ Run "loadScript('gethload.js')" and using "checkAllBalances()" to check for Account Balances
* When testing, miner didn't mine anything however it does not affect the project file since we are not using Geth for our project, Geth will just be a bonus.
